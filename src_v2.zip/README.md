# Node & MSSQL Server API
nodejs and Microsoft SQL Server Datbase REST API

## environment variables

```
DB_USER = youruser
DB_PASSWORD = yourpassword
DB_SERVER = localhost
DB_DATABASE = yourdatabase
```