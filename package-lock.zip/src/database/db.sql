--create database scada;
--CREATE TABLE products (
  --  id INT IDENTITY(1,1) PRIMARY KEY,
  --  name VARCHAR(100) NOT NULL,
   -- price DECIMAL(10, 2) ,
   -- quantity INT,
   -- description TEXT
--);

 
 
 --CREATE TABLE OrdenesProduccion (
 --   C2_FILIAL VARCHAR(2),
--    C2_NUM VARCHAR(20) PRIMARY KEY,        -- Número único de OP
 --   C2_PRODUTO VARCHAR(20),
 --   C2_QUANT DECIMAL(18,4),                -- Cantidad a producir
 --   C2_QUJE DECIMAL(18,4),                 -- Cantidad producida
 --   C2_EMISSAO DATE,
--    C2_DATPRF DATE,
 --   C2_CC VARCHAR(10)
--);

 --CREATE TABLE ReservasProductos (
  --  ID INT IDENTITY(1,1) PRIMARY KEY,
  --  D4_FILIAL VARCHAR(2),
  --  D4_COD VARCHAR(20),
  --  D4_LOCAL VARCHAR(10),
  --  D4_QUANT DECIMAL(18,4),                -- Cantidad reservada
  --  D4_QTDORI DECIMAL(18,4),               -- Cantidad original
  --  D4_EMISSAO DATE,
   -- D4_OP VARCHAR(20),                     -- Clave foránea a OrdenesProduccion.C2_NUM
   -- D4_CC VARCHAR(10),
   -- D4_DOC VARCHAR(20),
   -- D4_TES VARCHAR(3),
   -- D4_ESTORNO CHAR(1)
--);


--CREATE TABLE Productos (
 --   B1_COD VARCHAR(20) PRIMARY KEY,
  ---  B1_DESC VARCHAR(60),
    --B1_UM VARCHAR(6),
   -- B1_GRUPO VARCHAR(6),
   -- B1_TIPO VARCHAR(1),
   -- B1_POSIPI VARCHAR(10),
   -- B1_CODBAR VARCHAR(30)
--);

--SELECT * FROM OrdenesProduccion 
--SELECT * FROM ReservasProductos 

